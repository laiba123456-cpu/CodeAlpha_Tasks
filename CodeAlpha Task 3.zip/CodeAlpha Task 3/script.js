
// ========================================
// MUSIC PLAYER
// ========================================

// Create audio player
const audio = new Audio();


// ========================================
// SONGS / PLAYLIST
// ========================================

const songs = [

    {
        title: "SoundHelix Song 1",
        artist: "SoundHelix",
        src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
        image: "https://picsum.photos/300/300?random=1"
    },

    {
        title: "SoundHelix Song 2",
        artist: "SoundHelix",
        src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
        image: "https://picsum.photos/300/300?random=2"
    },

    {
        title: "SoundHelix Song 3",
        artist: "SoundHelix",
        src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
        image: "https://picsum.photos/300/300?random=3"
    }

];

// ========================================
// CURRENT SONG
// ========================================

let currentSong = 0;


// ========================================
// HTML ELEMENTS
// ========================================

const songTitle =
    document.getElementById("songTitle");

const artist =
    document.getElementById("artist");

const albumImage =
    document.getElementById("albumImage");

const playButton =
    document.getElementById("play");

const previousButton =
    document.getElementById("previous");

const nextButton =
    document.getElementById("next");

const progressBar =
    document.getElementById("progressBar");

const currentTime =
    document.getElementById("currentTime");

const duration =
    document.getElementById("duration");

const volume =
    document.getElementById("volume");

const playlist =
    document.getElementById("playlist");


// ========================================
// LOAD SONG
// ========================================

function loadSong(index) {

    const song = songs[index];

    songTitle.textContent = song.title;

    artist.textContent = song.artist;

    albumImage.src = song.image;

    audio.src = song.src;

    audio.load();

    progressBar.value = 0;

    currentTime.textContent = "0:00";

    duration.textContent = "0:00";

    updatePlaylist();
}


// ========================================
// PLAY SONG
// ========================================

function playSong() {

    audio.play()
        .then(function () {

            playButton.textContent = "⏸";

        })
        .catch(function (error) {

            console.log("Song could not play:", error);

            alert(
                "Song could not be played. " +
                "Please check that the MP3 file is inside the songs folder."
            );

        });

}


// ========================================
// PAUSE SONG
// ========================================

function pauseSong() {

    audio.pause();

    playButton.textContent = "▶";

}


// ========================================
// PLAY / PAUSE BUTTON
// ========================================

playButton.addEventListener("click", function () {

    if (audio.paused) {

        playSong();

    } else {

        pauseSong();

    }

});


// ========================================
// NEXT SONG
// ========================================

nextButton.addEventListener("click", function () {

    currentSong++;

    if (currentSong >= songs.length) {

        currentSong = 0;

    }

    loadSong(currentSong);

    playSong();

});


// ========================================
// PREVIOUS SONG
// ========================================

previousButton.addEventListener("click", function () {

    currentSong--;

    if (currentSong < 0) {

        currentSong = songs.length - 1;

    }

    loadSong(currentSong);

    playSong();

});


// ========================================
// UPDATE PROGRESS BAR
// ========================================

audio.addEventListener("timeupdate", function () {

    if (audio.duration) {

        const progress =
            (audio.currentTime / audio.duration) * 100;

        progressBar.value = progress;

        currentTime.textContent =
            formatTime(audio.currentTime);

        duration.textContent =
            formatTime(audio.duration);

    }

});


// ========================================
// CHANGE SONG POSITION
// ========================================

progressBar.addEventListener("input", function () {

    if (audio.duration) {

        audio.currentTime =
            (progressBar.value / 100) * audio.duration;

    }

});


// ========================================
// VOLUME CONTROL
// ========================================

volume.addEventListener("input", function () {

    audio.volume = volume.value;

});


// ========================================
// AUTOMATICALLY PLAY NEXT SONG
// ========================================

audio.addEventListener("ended", function () {

    currentSong++;

    if (currentSong >= songs.length) {

        currentSong = 0;

    }

    loadSong(currentSong);

    playSong();

});


// ========================================
// FORMAT TIME
// ========================================

function formatTime(time) {

    if (isNaN(time)) {

        return "0:00";

    }

    const minutes =
        Math.floor(time / 60);

    const seconds =
        Math.floor(time % 60);

    return minutes + ":" +
        (seconds < 10 ? "0" : "") +
        seconds;

}


// ========================================
// CREATE PLAYLIST
// ========================================

function updatePlaylist() {

    playlist.innerHTML = "";

    songs.forEach(function (song, index) {

        const li =
            document.createElement("li");

        li.textContent =
            song.title + " - " + song.artist;

        if (index === currentSong) {

            li.classList.add("active");

        }

        li.addEventListener("click", function () {

            currentSong = index;

            loadSong(currentSong);

            playSong();

        });

        playlist.appendChild(li);

    });

}


// ========================================
// INITIAL SETTINGS
// ========================================

audio.volume = 1;


// ========================================
// LOAD FIRST SONG
// ========================================

loadSong(currentSong);




