// Task no 1
const images = [
"https://picsum.photos/id/1015/800/600",
"https://picsum.photos/id/1011/800/600",
"https://picsum.photos/id/1025/800/600",
"https://picsum.photos/id/1040/800/600",
"https://picsum.photos/id/1031/800/600",
"https://picsum.photos/id/237/800/600"
];

let currentIndex = 0;

function openLightbox(index){

    currentIndex = index;

    document.getElementById("lightbox").style.display = "flex";

    document.getElementById("lightbox-img").src = images[currentIndex];

}

function closeLightbox(){

    document.getElementById("lightbox").style.display = "none";

}

function changeImage(step){

    currentIndex += step;

    if(currentIndex >= images.length){
        currentIndex = 0;
    }

    if(currentIndex < 0){
        currentIndex = images.length - 1;
    }

    document.getElementById("lightbox-img").src = images[currentIndex];

}

// Filter Function

function filterSelection(category){

    let items = document.getElementsByClassName("image");

    let buttons = document.querySelectorAll(".buttons button");

    buttons.forEach(btn => btn.classList.remove("active"));

    event.target.classList.add("active");

    for(let i=0;i<items.length;i++){

        if(category=="all"){

            items[i].style.display="block";

        }

        else if(items[i].classList.contains(category)){

            items[i].style.display="block";

        }

        else{

            items[i].style.display="none";

        }

    }

}