const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");

let expression = "";

buttons.forEach(button => {

    button.addEventListener("click", () => {

        const value = button.innerText;

        if(value === "C"){
            expression = "";
            display.value = "0";
        }

        else if(value === "⌫"){
            expression = expression.slice(0,-1);
            display.value = expression || "0";
        }

        else if(value === "="){

            try{

                if(expression==="") return;

                let result = eval(expression);

                if(!isFinite(result)){
                    display.value="Error";
                    expression="";
                    return;
                }

                display.value=result;
                expression=result.toString();

            }catch{
                display.value="Error";
                expression="";
            }

        }

        else{

            expression+=value;
            display.value=expression;

        }

    });

});

document.addEventListener("keydown",(e)=>{

    const key=e.key;

    if("0123456789+-*/.".includes(key)){
        expression+=key;
        display.value=expression;
    }

    if(key==="Enter"){
        e.preventDefault();

        try{

            let result=eval(expression);

            if(!isFinite(result)){
                display.value="Error";
                expression="";
                return;
            }

            display.value=result;
            expression=result.toString();

        }catch{

            display.value="Error";
            expression="";

        }
    }

    if(key==="Backspace"){
        expression=expression.slice(0,-1);
        display.value=expression || "0";
    }

    if(key==="Escape"){
        expression="";
        display.value="0";
    }

});